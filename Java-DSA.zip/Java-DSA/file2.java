import java.util.*;
import java.util.ArrayList;

public static void main(String [] args) {

    ArrayList<Integer> numbers = new ArrayList<>();

    numbers.add(45);
    numbers.add(20);
    numbers.add(14);
    numbers.add(11);
    numbers.add(69);
    numbers.add(76);

    numbers.sort(null);

         Collections.sort(numbers);

         for(int i = 0;i<numbers.size();i++) {
            System.out.println("The value at index: " + numbers.get(i));
         }

         for(Integer num: numbers) {
            System.out.print(num + " ");
         } 




}




public class file2 {
    
}

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Book {
    private String isbn;
    private String title;
    private String author;
    private boolean isAvailable;

    public Book(String isbn, String title, String author) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public boolean isAvailable() { return isAvailable; }
    
    public void setAvailable(boolean available) { isAvailable = available; }

    @Override
    public String toString() {
        String status = isAvailable ? Libb1010ra.GREEN + "SECURED" + Libb1010ra.CYAN : Libb1010ra.RED + "DEPLOYED" + Libb1010ra.CYAN;
        return String.format(" │ " + Libb1010ra.YELLOW + "%-5s" + Libb1010ra.CYAN + " │ " + Libb1010ra.WHITE + "%-40s" + Libb1010ra.CYAN + " │ " + Libb1010ra.WHITE + "%-25s" + Libb1010ra.CYAN + " │ %-18s │", 
                isbn, title, author, status);
    }
}

class User {
    private String username;
    private String password;
    private boolean isAdmin;

    public User(String username, String password, boolean isAdmin) {
        this.username = username;
        this.password = password;
        this.isAdmin = isAdmin;
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public boolean isAdmin() { return isAdmin; }
}

class Library {
    private List<Book> books;
    private List<User> users;

    public Library() {
        this.books = new ArrayList<>();
        this.users = new ArrayList<>();
        
        users.add(new User("admin", "admin123", true));
        seedBooks();
    }

    private void seedBooks() {
        books.add(new Book("101", "The Hobbit", "J.R.R. Tolkien"));
        books.add(new Book("102", "1984", "George Orwell"));
        books.add(new Book("103", "To Kill a Mockingbird", "Harper Lee"));
        books.add(new Book("104", "The Great Gatsby", "F. Scott Fitzgerald"));
        books.add(new Book("105", "Moby Dick", "Herman Melville"));
        books.add(new Book("106", "Pride and Prejudice", "Jane Austen"));
        books.add(new Book("107", "The Catcher in the Rye", "J.D. Salinger"));
        books.add(new Book("108", "Brave New World", "Aldous Huxley"));
        books.add(new Book("109", "The Odyssey", "Homer"));
        books.add(new Book("110", "Crime and Punishment", "Fyodor Dostoevsky"));
        books.add(new Book("121", "Dune", "Frank Herbert"));
        books.add(new Book("122", "Neuromancer", "William Gibson"));
        books.add(new Book("123", "Foundation", "Isaac Asimov"));
        books.add(new Book("127", "The Hitchhiker's Guide to the Galaxy", "Douglas Adams"));
        books.add(new Book("151", "Atomic Habits", "James Clear"));
        books.add(new Book("152", "Deep Work", "Cal Newport"));
    }

    public boolean registerUser(String username, String password, boolean isAdmin) {
        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                return false; 
            }
        }
        users.add(new User(username, password, isAdmin));
        return true;
    }

    public User loginUser(String username, String password) {
        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(username) && u.getPassword().equals(password)) {
                return u;
            }
        }
        return null;
    }

    public void addBook(Book book) {
        books.add(book);
        Libb1010ra.printFrame("ARCHIVE SUCCESS", "Item '" + book.getTitle() + "' successfully logged into Central Core.", Libb1010ra.GREEN);
    }

    public void displayBooks() {
        if (books.isEmpty()) {
            Libb1010ra.printFrame("ERROR", "The data archives are currently empty.", Libb1010ra.RED);
            return;
        }
        
        System.out.println(Libb1010ra.CYAN + "┌───────┬──────────────────────────────────────────┬───────────────────────────┬──────────────────┐");
        System.out.println("│ " + Libb1010ra.YELLOW + "INDEX" + Libb1010ra.CYAN + " │ " + Libb1010ra.YELLOW + "DATASTREAM TITLE" + Libb1010ra.CYAN + "                         │ " + Libb1010ra.YELLOW + "CREATOR/AUTHOR" + Libb1010ra.CYAN + "            │ " + Libb1010ra.YELLOW + "CORE STATUS" + Libb1010ra.CYAN + "      │");
        System.out.println("├───────┼──────────────────────────────────────────┼───────────────────────────┼──────────────────┤");
        for (Book book : books) {
            System.out.println(book);
        }
        System.out.println("└───────┴──────────────────────────────────────────┴───────────────────────────┴──────────────────┘" + Libb1010ra.RESET);
    }

    public void borrowBook(String isbn) {
        Book book = findBook(isbn);
        if (book == null) {
            Libb1010ra.printFrame("TRANSMISSION ERROR", "Index key [" + isbn + "] does not exist in archives.", Libb1010ra.RED);
        } else if (!book.isAvailable()) {
            Libb1010ra.printFrame("ACCESS DENIED", "'" + book.getTitle() + "' status is currently DEPLOYED.", Libb1010ra.RED);
        } else {
            book.setAvailable(false);
            Libb1010ra.printFrame("DECRYPTION SUCCESS", "You have successfully extracted '" + book.getTitle() + "'.", Libb1010ra.GREEN);
        }
    }

    public void returnBook(String isbn) {
        Book book = findBook(isbn);
        if (book == null) {
            Libb1010ra.printFrame("FOREIGN OBJECT", "This item matches no signatures in this sector.", Libb1010ra.RED);
        } else if (book.isAvailable()) {
            Libb1010ra.printFrame("INTEGRITY ERROR", "Anomalous Action: Item is already secured in core.", Libb1010ra.YELLOW);
        } else {
            book.setAvailable(true);
            Libb1010ra.printFrame("RE-INTEGRATION COMPLETE", "'" + book.getTitle() + "' has been re-secured.", Libb1010ra.GREEN);
        }
    }

    private Book findBook(String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equalsIgnoreCase(isbn)) {
                return book;
            }
        }
        return null;
    }
}

public class Libb1010ra
 {
    // Sci-fi Neon ANSI Color Codes
    public static final String RESET = "\u001B[0m";
    public static final String BOLD = "\u001B[1m";
    public static final String RED = "\u001B[1;31m";
    public static final String GREEN = "\u001B[1;32m";
    public static final String YELLOW = "\u001B[1;33m";
    public static final String CYAN = "\u001B[1;36m";
    public static final String WHITE = "\u001B[1;37m";

    private static Library library = new Library();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            showMainMenu();
            System.out.print(CYAN + "║ " + YELLOW + "INITIALIZE COMMAND: " + RESET);
            
            int choice = getIntInput();
            switch (choice) {
                case 1:
                    handleLogin();
                    break;
                case 2:
                    handleRegistration();
                    break;
                case 3:
                    printFrame("SHUTTING DOWN", "Terminating neural link... Goodbye User.", Libb1010ra.RED);
                    running = false;
                    break;
                default:
                    printFrame("WARNING", "Invalid Directive. Re-enter parameters.", Libb1010ra.YELLOW);
            }
        }
        scanner.close();
    }

    private static void showMainMenu() {
        System.out.println("\n" + CYAN + "╔══════════════════════════════════════════════╗");
        System.out.println("║ " + WHITE + BOLD + "       N E X U S   C O R E   L I B R A R Y    " + CYAN + "║");
        System.out.println("╠══════════════════════════════════════════════╣");
        System.out.println("║ " + GREEN + "  [1] STAGE NEURAL LOGIN                      " + CYAN + "║");
        System.out.println("║ " + GREEN + "  [2] CREATE NEW NETWORK IDENTIFICATION       " + CYAN + "║");
        System.out.println("║ " + RED + "  [3] DISCONNECT SYSTEM                       " + CYAN + "║");
        System.out.println("╚══════════════════════════════════════════════╝");
    }

    private static void handleRegistration() {
        System.out.println("\n" + CYAN + "┌─── [ NEW PROFILE ACCESS ] ───┐" + RESET);
        System.out.print(CYAN + " │ USERNAME: " + RESET);
        String user = scanner.nextLine();
        System.out.print(CYAN + " │ PASSKEY:  " + RESET);
        String pass = scanner.nextLine();
        System.out.print(CYAN + " │ ELEVATE TO ADMIN? (yes/no): " + RESET);
        String adminCheck = scanner.nextLine();
        boolean isAdmin = adminCheck.equalsIgnoreCase("yes");

        if (library.registerUser(user, pass, isAdmin)) {
            printFrame("REGISTRATION SUCCESS", "Identity registered in global databanks.", Libb1010ra.GREEN);
        } else {
            printFrame("REGISTRATION FAILED", "Identity signature collision detected.", Libb1010ra.RED);
        }
    }

    private static void handleLogin() {
        System.out.println("\n" + CYAN + "┌─── [ SECURE LOGIN OVERRIDE ] ───┐" + RESET);
        System.out.print(CYAN + " │ USERNAME: " + RESET);
        String user = scanner.nextLine();
        System.out.print(CYAN + " │ PASSKEY:  " + RESET);
        String pass = scanner.nextLine();

        User loggedInUser = library.loginUser(user, pass);

        if (loggedInUser != null) {
            printFrame("ACCESS GRANTED", "Welcome back, Operator [" + loggedInUser.getUsername().toUpperCase() + "].", Libb1010ra.GREEN);
            if (loggedInUser.isAdmin()) {
                showAdminPanel();
            } else {
                showUserPanel();
            }
        } else {
            printFrame("ACCESS DENIED", "Invalid credentials. Tracing IP...", Libb1010ra.RED);
        }
    }

    private static void showAdminPanel() {
        boolean inAdmin = true;
        while (inAdmin) {
            System.out.println("\n" + RED + "╔══════════════════════════════════════════════╗");
            System.out.println("║ " + WHITE + BOLD + "        C O R E   A D M I N   P A N E L       " + RED + "║");
            System.out.println("╠══════════════════════════════════════════════╣");
            System.out.println("║ " + YELLOW + "  [1] INJECT NEW DATASET (ADD BOOK)           " + RED + "║");
            System.out.println("║ " + YELLOW + "  [2] AUDIT COMPLETE CATALOG                  " + RED + "║");
            System.out.println("║ " + WHITE + "  [3] LOG OUT FROM TERMINAL                   " + RED + "║");
            System.out.println("╚══════════════════════════════════════════════╝");
            System.out.print(RED + "║ " + YELLOW + "EXECUTE: " + RESET);

            int choice = getIntInput();
            switch (choice) {
                case 1:
                    System.out.print(RED + " │ ENTER INDEX (ISBN): " + RESET);
                    String isbn = scanner.nextLine();
                    System.out.print(RED + " │ ENTER DATA TITLE:   " + RESET);
                    String title = scanner.nextLine();
                    System.out.print(RED + " │ ENTER CREATOR ID:   " + RESET);
                    String author = scanner.nextLine();
                    library.addBook(new Book(isbn, title, author));
                    break;
                case 2:
                    library.displayBooks();
                    break;
                case 3:
                    inAdmin = false;
                    printFrame("LOGOUT SECURE", "Admin terminal session ended.", Libb1010ra.CYAN);
                    break;
                default:
                    printFrame("ERROR", "Invalid Operation Node.", Libb1010ra.RED);
            }
        }
    }

    private static void showUserPanel() {
        boolean inUser = true;
        while (inUser) {
            System.out.println("\n" + GREEN + "╔══════════════════════════════════════════════╗");
            System.out.println("║ " + WHITE + BOLD + "        M A T R I X   U S E R   M E N U       " + GREEN + "║");
            System.out.println("╠══════════════════════════════════════════════╣");
            System.out.println("║ " + CYAN + "  [1] DISPLAY ALL ARCHIVED DATA               " + GREEN + "║");
            System.out.println("║ " + CYAN + "  [2] EXTRACT DATASET (BORROW)                " + GREEN + "║");
            System.out.println("║ " + CYAN + "  [3] RE-INTEGRATE DATASET (RETURN)           " + GREEN + "║");
            System.out.println("║ " + WHITE + "  [4] TERMINATE SESSION (LOG OUT)             " + GREEN + "║");
            System.out.println("╚══════════════════════════════════════════════╝");
            System.out.print(GREEN + "║ " + YELLOW + "EXECUTE: " + RESET);

            int choice = getIntInput();
            switch (choice) {
                case 1:
                    library.displayBooks();
                    break;
                case 2:
                    System.out.print(GREEN + " │ ENTER EXTRACTION INDEX (ISBN): " + RESET);
                    String borrowIsbn = scanner.nextLine();
                    library.borrowBook(borrowIsbn);
                    break;
                case 3:
                    System.out.print(GREEN + " │ ENTER TARGET RE-ENTRY INDEX (ISBN): " + RESET);
                    String returnIsbn = scanner.nextLine();
                    library.returnBook(returnIsbn);
                    break;
                case 4:
                    inUser = false;
                    printFrame("LOGOUT SECURE", "User mainframe connection closed.", Libb1010ra.CYAN);
                    break;
                default:
                    printFrame("ERROR", "Invalid Stream Node.", Libb1010ra.RED);
            }
        }
    }

    private static int getIntInput() {
        while (!scanner.hasNextInt()) {
            printFrame("PARSE FAULT", "Integers only. Re-routing input stream...", Libb1010ra.RED);
            System.out.print(CYAN + "║ " + YELLOW + "RE-ENTER CHOICE: " + RESET);
            scanner.next();
        }
        int val = scanner.nextInt();
        scanner.nextLine(); 
        return val;
    }

    // Dynamic Futuristic Box Printer Helper
    public static void printFrame(String title, String message, String colorCode) {
        int width = 70;
        String border = colorCode + "▰".repeat(width) + RESET;
        System.out.println(border);
        System.out.printf("%s▰▰ [ %s%s%s ] %s\n", colorCode, WHITE, title, colorCode, ".".repeat(width - title.length() - 9) + RESET);
        System.out.println(WHITE + "  " + message + RESET);
        System.out.println(border);
    }
}
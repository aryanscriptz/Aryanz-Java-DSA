import java.util.Scanner;
import java.math.BigInteger;

public class Factorialofn {
    public static void main(String[] args) 
    { 
        int n;
        BigInteger factorial = BigInteger.valueOf(1);
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        n = sc.nextInt();       
        for (int i = 1; i <= n; i++) 
        { 
            factorial = factorial.multiply(BigInteger.valueOf(i));  
        } 
        System.out.println("Factorial of " + n + " is: " + factorial);
    }
}


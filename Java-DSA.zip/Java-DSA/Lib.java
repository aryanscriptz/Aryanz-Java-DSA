import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Libb1010ook {
    private String isbn;
    private String title;
    private String author;
    private boolean isAvailable;

    public Libb1010ook(String isbn, String title, String author) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public boolean isAvailable() { return isAvailable; }
    
    public void setAvailable(boolean available) { isAvailable = available; }

    @Override
    public String toString() {
        return String.format("ISBN: %s | Title: %s | Author: %s | Status: %s", 
                isbn, title, author, (isAvailable ? "Available" : "Borrowed"));
    }
}

class LibUser {
    private String username;
    private String password;
    private boolean isAdmin;

    public LibUser(String username, String password, boolean isAdmin) {
        this.username = username;
        this.password = password;
        this.isAdmin = isAdmin;
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public boolean isAdmin() { return isAdmin; }
}

class LibLibrary {
    private List<Libb1010ook> books;
    private List<LibUser> users;

    public LibLibrary() {
        this.books = new ArrayList<>();
        this.users = new ArrayList<>();
        
        users.add(new LibUser("admin", "admin123", true));
        
        seedBooks();
    }

    private void seedBooks() {
        books.add(new Libb1010ook("101", "The Hobbit", "J.R.R. Tolkien"));
        books.add(new Libb1010ook("102", "1984", "George Orwell"));
        books.add(new Libb1010ook("103", "To Kill a Mockingbird", "Harper Lee"));
        books.add(new Libb1010ook("104", "The Great Gatsby", "F. Scott Fitzgerald"));
        books.add(new Libb1010ook("105", "Moby Dick", "Herman Melville"));
        books.add(new Libb1010ook("106", "Pride and Prejudice", "Jane Austen"));
        books.add(new Libb1010ook("107", "The Catcher in the Rye", "J.D. Salinger"));
        books.add(new Libb1010ook("108", "Brave New World", "Aldous Huxley"));
        books.add(new Libb1010ook("109", "The Odyssey", "Homer"));
        books.add(new Libb1010ook("110", "Crime and Punishment", "Fyodor Dostoevsky"));
        books.add(new Libb1010ook("111", "The Lord of the Rings", "J.R.R. Tolkien"));
        books.add(new Libb1010ook("112", "Frankenstein", "Mary Shelley"));
        books.add(new Libb1010ook("113", "The Catch-22", "Joseph Heller"));
        books.add(new Libb1010ook("114", "The Grapes of Wrath", "John Steinbeck"));
        books.add(new Libb1010ook("115", "Lolita", "Vladimir Nabokov"));
        books.add(new Libb1010ook("116", "Ulysses", "James Joyce"));
        books.add(new Libb1010ook("117", "The Divine Comedy", "Dante Alighieri"));
        books.add(new Libb1010ook("118", "Wuthering Heights", "Emily Bronte"));
        books.add(new Libb1010ook("119", "Madame Bovary", "Gustave Flaubert"));
        books.add(new Libb1010ook("120", "The Iliad", "Homer"));
        books.add(new Libb1010ook("121", "Dune", "Frank Herbert"));
        books.add(new Libb1010ook("122", "Neuromancer", "William Gibson"));
        books.add(new Libb1010ook("123", "Foundation", "Isaac Asimov"));
        books.add(new Libb1010ook("124", "Snow Crash", "Neal Stephenson"));
        books.add(new Libb1010ook("125", "The Left Hand of Darkness", "Ursula K. Le Guin"));
        books.add(new Libb1010ook("126", "Hyperion", "Dan Simmons"));
        books.add(new Libb1010ook("127", "The Hitchhiker's Guide to the Galaxy", "Douglas Adams"));
        books.add(new Libb1010ook("128", "Ender's Game", "Orson Scott Card"));
        books.add(new Libb1010ook("129", "Fahrenheit 451", "Ray Bradbury"));
        books.add(new Libb1010ook("130", "Do Androids Dream of Electric Sheep?", "Philip K. Dick"));
        books.add(new Libb1010ook("131", "The Girl with the Dragon Tattoo", "Stieg Larsson"));
        books.add(new Libb1010ook("132", "Gone Girl", "Gillian Flynn"));
        books.add(new Libb1010ook("133", "The Da Vinci Code", "Dan Brown"));
        books.add(new Libb1010ook("134", "Angels & Demons", "Dan Brown"));
        books.add(new Libb1010ook("135", "The Silent Patient", "Alex Michaelides"));
        books.add(new Libb1010ook("136", "The Big Sleep", "Raymond Chandler"));
        books.add(new Libb1010ook("137", "And Then There Were None", "Agatha Christie"));
        books.add(new Libb1010ook("138", "Murder on the Orient Express", "Agatha Christie"));
        books.add(new Libb1010ook("139", "The Hound of the Baskervilles", "Arthur Conan Doyle"));
        books.add(new Libb1010ook("140", "A Study in Scarlet", "Arthur Conan Doyle"));
        books.add(new Libb1010ook("141", "Sapiens", "Yuval Noah Harari"));
        books.add(new Libb1010ook("142", "Homo Deus", "Yuval Noah Harari"));
        books.add(new Libb1010ook("143", "Educated", "Tara Westover"));
        books.add(new Libb1010ook("144", "Becoming", "Michelle Obama"));
        books.add(new Libb1010ook("145", "Thinking, Fast and Slow", "Daniel Kahneman"));
        books.add(new Libb1010ook("146", "A Brief History of Time", "Stephen Hawking"));
        books.add(new Libb1010ook("147", "The Selfish Gene", "Richard Dawkins"));
        books.add(new Libb1010ook("148", "Cosmos", "Carl Sagan"));
        books.add(new Libb1010ook("149", "Guns, Germs, and Steel", "Jared Diamond"));
        books.add(new Libb1010ook("150", "The Power of Habit", "Charles Duhigg"));
        books.add(new Libb1010ook("151", "Atomic Habits", "James Clear"));
        books.add(new Libb1010ook("152", "Deep Work", "Cal Newport"));
        books.add(new Libb1010ook("153", "The Lean Startup", "Eric Ries"));
        books.add(new Libb1010ook("154", "Zero to One", "Peter Thiel"));
        books.add(new Libb1010ook("155", "Good to Great", "Jim Collins"));
        books.add(new Libb1010ook("156", "Outliers", "Malcolm Gladwell"));
        books.add(new Libb1010ook("157", "Blink", "Malcolm Gladwell"));
        books.add(new Libb1010ook("158", "Quiet", "Susan Cain"));
        books.add(new Libb1010ook("159", "The Subtle Art of Not Giving a F*ck", "Mark Manson"));
        books.add(new Libb1010ook("160", "Man's Search for Meaning", "Viktor Frankl"));
        books.add(new Libb1010ook("161", "The Alchemist", "Paulo Coelho"));
        books.add(new Libb1010ook("162", "The Road", "Cormac McCarthy"));
        books.add(new Libb1010ook("163", "The Book Thief", "Markus Zusak"));
    }

    public boolean registerUser(String username, String password, boolean isAdmin) {
        for (LibUser u : users) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                return false; 
            }
        }
        users.add(new LibUser(username, password, isAdmin));
        return true;
    }

    public LibUser loginUser(String username, String password) {
        for (LibUser u : users) {
            if (u.getUsername().equalsIgnoreCase(username) && u.getPassword().equals(password)) {
                return u;
            }
        }
        return null;
    }

    public void addBook(Libb1010ook book) {
        books.add(book);
        System.out.println("Book added successfully: " + book.getTitle());
    }

    public void displayBooks() {
        if (books.isEmpty()) {
            System.out.println("The library is currently empty.");
            return;
        }
        System.out.println("\n--- Library Catalog ---");
        for (Libb1010ook book : books) {
            System.out.println(book);
        }
    }

    public void borrowBook(String isbn) {
        Libb1010ook book = findBook(isbn);
        if (book == null) {
            System.out.println("Error: Book with ISBN " + isbn + " not found.");
        } else if (!book.isAvailable()) {
            System.out.println("Sorry, '" + book.getTitle() + "' is already borrowed.");
        } else {
            book.setAvailable(false);
            System.out.println("Success! You have borrowed '" + book.getTitle() + "'.");
        }
    }

    public void returnBook(String isbn) {
        Libb1010ook book = findBook(isbn);
        if (book == null) {
            System.out.println("Error: This book does not belong to this library.");
        } else if (book.isAvailable()) {
            System.out.println("Verification failed: This book was not marked as borrowed.");
        } else {
            book.setAvailable(true);
            System.out.println("Success! '" + book.getTitle() + "' has been returned.");
        }
    }

    private Libb1010ook findBook(String isbn) {
        for (Libb1010ook book : books) {
            if (book.getIsbn().equalsIgnoreCase(isbn)) {
                return book;
            }
        }
        return null;
    }
}

public class Lib {
    private static LibLibrary library = new LibLibrary();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            System.out.println("\n===== WELCOME TO THE LIBRARY =====");
            System.out.println("1. Login");
            System.out.println("2. Open New Account");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            
            int choice = getIntInput();
            
            switch (choice) {
                case 1:
                    handleLogin();
                    break;
                case 2:
                    handleRegistration();
                    break;
                case 3:
                    System.out.println("Exiting system. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
        scanner.close();
    }

    private static void handleRegistration() {
        System.out.print("Enter new username: ");
        String user = scanner.nextLine();
        System.out.print("Enter new password: ");
        String pass = scanner.nextLine();
        System.out.print("Is this an admin account? (yes/no): ");
        String adminCheck = scanner.nextLine();
        boolean isAdmin = adminCheck.equalsIgnoreCase("yes");

        if (library.registerUser(user, pass, isAdmin)) {
            System.out.println("Account created successfully!");
        } else {
            System.out.println("Registration failed. Username already exists.");
        }
    }

    private static void handleLogin() {
        System.out.print("Username: ");
        String user = scanner.nextLine();
        System.out.print("Password: ");
        String pass = scanner.nextLine();

        LibUser loggedInUser = library.loginUser(user, pass);

        if (loggedInUser != null) {
            System.out.println("\nWelcome, " + loggedInUser.getUsername() + "!");
            if (loggedInUser.isAdmin()) {
                showAdminPanel();
            } else {
                showUserPanel();
            }
        } else {
            System.out.println("Invalid username or password.");
        }
    }

    private static void showAdminPanel() {
        boolean inAdmin = true;
        while (inAdmin) {
            System.out.println("\n--- ADMIN PANEL ---");
            System.out.println("1. Add a New Book");
            System.out.println("2. Display All Books");
            System.out.println("3. Log out");
            System.out.print("Enter choice: ");

            int choice = getIntInput();
            switch (choice) {
                case 1:
                    System.out.print("Enter ISBN: ");
                    String isbn = scanner.nextLine();
                    System.out.print("Enter Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter Author: ");
                    String author = scanner.nextLine();
                    library.addBook(new Libb1010ook(isbn, title, author));
                    break;
                case 2:
                    library.displayBooks();
                    break;
                case 3:
                    inAdmin = false;
                    System.out.println("Logged out of Admin Panel.");
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    private static void showUserPanel() {
        boolean inUser = true;
        while (inUser) {
            System.out.println("\n--- USER PANEL ---");
            System.out.println("1. View Available Books");
            System.out.println("2. Borrow a Book");
            System.out.println("3. Return a Book");
            System.out.println("4. Log out");
            System.out.print("Enter choice: ");

            int choice = getIntInput();
            switch (choice) {
                case 1:
                    library.displayBooks();
                    break;
                case 2:
                    System.out.print("Enter ISBN to borrow: ");
                    String borrowIsbn = scanner.nextLine();
                    library.borrowBook(borrowIsbn);
                    break;
                case 3:
                    System.out.print("Enter ISBN to return: ");
                    String returnIsbn = scanner.nextLine();
                    library.returnBook(returnIsbn);
                    break;
                case 4:
                    inUser = false;
                    System.out.println("Logged out of User Panel.");
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    private static int getIntInput() {
        while (!scanner.hasNextInt()) {
            System.out.println("Please enter a valid number.");
            scanner.next();
        }
        int val = scanner.nextInt();
        scanner.nextLine(); 
        return val;
    }
}

class Animal 
{
    void eat() 
    {
        System.out.println("This animal eats food.");
    }
}
    class Dog extends Animal 
    {
        void bark() 
        {
            System.out.println("The dog barks.");
        }
    }
class Puppy extends Dog 
{
    void weep() 
    {
        System.out.println("The puppy weeps.");
    }
}

 class cat extends Animal
{
    void meow()
    {
        System.out.println("The cat meows.");
    }
}
public class HierarchicalInheritance
{
    public static void main(String[] args) 
    {
        Puppy puppy = new Puppy();
        puppy.eat();
        puppy.bark();
        puppy.weep();
        cat cat = new cat();
        cat.eat();
        cat.meow(); 
    }
}

   
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class LibbraBook {
    private String isbn;
    private String title;
    private String author;
    private boolean isAvailable;

    // FIX: Changed constructor name to match class name
    public LibbraBook(String isbn, String title, String author) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }

    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public boolean isAvailable() { return isAvailable; }
    
    public void setAvailable(boolean available) { isAvailable = available; }

    @Override
    public String toString() {
        String status = isAvailable ? Libb.GREEN + "SECURED" + Libb.CYAN : Libb.RED + "DEPLOYED" + Libb.CYAN;
        return String.format(" │ " + Libb.YELLOW + "%-5s" + Libb.CYAN + " │ " + Libb.WHITE + "%-40s" + Libb.CYAN + " │ " + Libb.WHITE + "%-25s" + Libb.CYAN + " │ %-18s │", 
                isbn, title, author, status);
    }
}

class LibbraUser {
    private String username;
    private String password;
    private boolean isAdmin;

    // FIX: Changed constructor name to match class name
    public LibbraUser(String username, String password, boolean isAdmin) {
        this.username = username;
        this.password = password;
        this.isAdmin = isAdmin;
    }

    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public boolean isAdmin() { return isAdmin; }
}

class LibbraLibrary {
    private List<LibbraBook> books;
    private List<LibbraUser> users;

    // FIX: Changed constructor name to match class name
    public LibbraLibrary() {
        this.books = new ArrayList<>();
        this.users = new ArrayList<>();
        
        // FIX: Using LibbraUser instead of User
        users.add(new LibbraUser("admin", "admin123", true));
        seedBooks();
    }

    private void seedBooks() {
        // FIX: Using LibbraBook instead of Book
        books.add(new LibbraBook("101", "The Hobbit", "J.R.R. Tolkien"));
        books.add(new LibbraBook("102", "1984", "George Orwell"));
        books.add(new LibbraBook("103", "To Kill a Mockingbird", "Harper Lee"));
        books.add(new LibbraBook("104", "The Great Gatsby", "F. Scott Fitzgerald"));
        books.add(new LibbraBook("105", "Moby Dick", "Herman Melville"));
        books.add(new LibbraBook("106", "Pride and Prejudice", "Jane Austen"));
        books.add(new LibbraBook("107", "The Catcher in the Rye", "J.D. Salinger"));
        books.add(new LibbraBook("108", "Brave New World", "Aldous Huxley"));
        books.add(new LibbraBook("109", "The Odyssey", "Homer"));
        books.add(new LibbraBook("110", "Crime and Punishment", "Fyodor Dostoevsky"));
        books.add(new LibbraBook("121", "Dune", "Frank Herbert"));
        books.add(new LibbraBook("122", "Neuromancer", "William Gibson"));
        books.add(new LibbraBook("123", "Foundation", "Isaac Asimov"));
        books.add(new LibbraBook("127", "The Hitchhiker's Guide to the Galaxy", "Douglas Adams"));
        books.add(new LibbraBook("151", "Atomic Habits", "James Clear"));
        books.add(new LibbraBook("152", "Deep Work", "Cal Newport"));
    }

    public boolean registerUser(String username, String password, boolean isAdmin) {
        for (LibbraUser u : users) {
            if (u.getUsername().equalsIgnoreCase(username)) {
                return false; 
            }
        }
        users.add(new LibbraUser(username, password, isAdmin));
        return true;
    }

    public LibbraUser loginUser(String username, String password) {
        for (LibbraUser u : users) {
            if (u.getUsername().equalsIgnoreCase(username) && u.getPassword().equals(password)) {
                return u;
            }
        }
        return null;
    }

    // FIX: Parameter updated to LibbraBook
    public void addBook(LibbraBook book) {
        books.add(book);
        Libb.printFrame("ARCHIVE SUCCESS", "Item '" + book.getTitle() + "' successfully logged into Central Core.", Libb.GREEN);
    }

    public void displayBooks() {
        if (books.isEmpty()) {
            Libb.printFrame("ERROR", "The data archives are currently empty.", Libb.RED);
            return;
        }
        
        System.out.println(Libb.CYAN + "┌───────┬──────────────────────────────────────────┬───────────────────────────┬──────────────────┐");
        System.out.println("│ " + Libb.YELLOW + "INDEX" + Libb.CYAN + " │ " + Libb.YELLOW + "DATASTREAM TITLE" + Libb.CYAN + "                          │ " + Libb.YELLOW + "CREATOR/AUTHOR" + Libb.CYAN + "            │ " + Libb.YELLOW + "CORE STATUS" + Libb.CYAN + "      │");
        System.out.println("├───────┼──────────────────────────────────────────┼───────────────────────────┼──────────────────┤");
        for (LibbraBook book : books) {
            System.out.println(book);
        }
        System.out.println("└───────┴──────────────────────────────────────────┴───────────────────────────┴──────────────────┘" + Libb.RESET);
    }

    public void borrowBook(String isbn) {
        LibbraBook book = findBook(isbn);
        if (book == null) {
            Libb.printFrame("TRANSMISSION ERROR", "Index key [" + isbn + "] does not exist in archives.", Libb.RED);
        } else if (!book.isAvailable()) {
            Libb.printFrame("ACCESS DENIED", "'" + book.getTitle() + "' status is currently DEPLOYED.", Libb.RED);
        } else {
            book.setAvailable(false);
            Libb.printFrame("DECRYPTION SUCCESS", "You have successfully extracted '" + book.getTitle() + "'.", Libb.GREEN);
        }
    }

    public void returnBook(String isbn) {
        LibbraBook book = findBook(isbn);
        if (book == null) {
            Libb.printFrame("FOREIGN OBJECT", "This item matches no signatures in this sector.", Libb.RED);
        } else if (book.isAvailable()) {
            Libb.printFrame("INTEGRITY ERROR", "Anomalous Action: Item is already secured in core.", Libb.YELLOW);
        } else {
            book.setAvailable(true);
            Libb.printFrame("RE-INTEGRATION COMPLETE", "'" + book.getTitle() + "' has been re-secured.", Libb.GREEN);
        }
    }

    // FIX: Return type and loop variable changed to LibbraBook
    private LibbraBook findBook(String isbn) {
        for (LibbraBook book : books) {
            if (book.getIsbn().equalsIgnoreCase(isbn)) {
                return book;
            }
        }
        return null;
    }
}

public class Libb10 {
    // Sci-fi Neon ANSI Color Codes
    public static final String RESET = "\u001B[0m";
    public static final String BOLD = "\u001B[1m";
    public static final String RED = "\u001B[1;31m";
    public static final String GREEN = "\u001B[1;32m";
    public static final String YELLOW = "\u001B[1;33m";
    public static final String CYAN = "\u001B[1;36m";
    public static final String WHITE = "\u001B[1;37m";

    // FIX: Type updated to LibbraLibrary
    private static LibbraLibrary library = new LibbraLibrary();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            showMainMenu();
            System.out.print(CYAN + "║ " + YELLOW + "INITIALIZE COMMAND: " + RESET);
            
            int choice = getIntInput();
            switch (choice) {
                case 1:
                    handleLogin();
                    break;
                case 2:
                    handleRegistration();
                    break;
                case 3:
                    printFrame("SHUTTING DOWN", "Terminating neural link... Goodbye User.", Libb.RED);
                    running = false;
                    break;
                default:
                    printFrame("WARNING", "Invalid Directive. Re-enter parameters.", Libb.YELLOW);
            }
        }
        scanner.close();
    }

    private static void showMainMenu() {
        System.out.println("\n" + CYAN + "╔══════════════════════════════════════════════╗");
        System.out.println("║ " + WHITE + BOLD + "       A R Y A N Z   C O R E   L I B R A R Y    " + CYAN + "║");
        System.out.println("╠══════════════════════════════════════════════╣");
        System.out.println("║ " + GREEN + "  [1] STAGE NEURAL LOGIN                      " + CYAN + "║");
        System.out.println("║ " + GREEN + "  [2] CREATE NEW NETWORK IDENTIFICATION        " + CYAN + "║");
        System.out.println("║ " + RED + "  [3] DISCONNECT SYSTEM                       " + CYAN + "║");
        System.out.println("╚══════════════════════════════════════════════╝");
    }

    private static void handleRegistration() {
        System.out.println("\n" + CYAN + "┌─── [ NEW PROFILE ACCESS ] ───┐" + RESET);
        System.out.print(CYAN + " │ USERNAME: " + RESET);
        String user = scanner.nextLine();
        System.out.print(CYAN + " │ PASSKEY:  " + RESET);
        String pass = scanner.nextLine();
        System.out.print(CYAN + " │ ELEVATE TO ADMIN? (yes/no): " + RESET);
        String adminCheck = scanner.nextLine();
        boolean isAdmin = adminCheck.equalsIgnoreCase("yes");

        if (library.registerUser(user, pass, isAdmin)) {
            printFrame("REGISTRATION SUCCESS", "Identity registered in global databanks.", Libb.GREEN);
        } else {
            printFrame("REGISTRATION FAILED", "Identity signature collision detected.", Libb.RED);
        }
    }

    private static void handleLogin() {
        System.out.println("\n" + CYAN + "┌─── [ SECURE LOGIN OVERRIDE ] ───┐" + RESET);
        System.out.print(CYAN + " │ USERNAME: " + RESET);
        String user = scanner.nextLine();
        System.out.print(CYAN + " │ PASSKEY:  " + RESET);
        String pass = scanner.nextLine();

        // FIX: Variable type updated to LibbraUser
        LibbraUser loggedInUser = library.loginUser(user, pass);

        if (loggedInUser != null) {
            printFrame("ACCESS GRANTED", "Welcome back, Operator [" + loggedInUser.getUsername().toUpperCase() + "].", Libb.GREEN);
            if (loggedInUser.isAdmin()) {
                showAdminPanel();
            } else {
                showUserPanel();
            }
        } else {
            printFrame("ACCESS DENIED", "Invalid credentials. Tracing IP...", Libb.RED);
        }
    }

    private static void showAdminPanel() {
        boolean inAdmin = true;
        while (inAdmin) {
            System.out.println("\n" + RED + "╔══════════════════════════════════════════════╗");
            System.out.println("║ " + WHITE + BOLD + "        C O R E   A D M I N   P A N E L        " + RED + "║");
            System.out.println("╠══════════════════════════════════════════════╣");
            System.out.println("║ " + YELLOW + "  [1] ADD BOOK           " + RED + "║");
            System.out.println("║ " + YELLOW + "  [2] AUDIT COMPLETE CATALOG                  " + RED + "║");
            System.out.println("║ " + WHITE + "  [3] LOG OUT FROM TERMINAL                   " + RED + "║");
            System.out.println("╚══════════════════════════════════════════════╝");
            System.out.print(RED + "║ " + YELLOW + "EXECUTE: " + RESET);

            int choice = getIntInput();
            switch (choice) {
                case 1:
                    System.out.print(RED + " │ ENTER INDEX (ISBN): " + RESET);
                    String isbn = scanner.nextLine();
                    System.out.print(RED + " │ ENTER DATA TITLE:   " + RESET);
                    String title = scanner.nextLine();
                    System.out.print(RED + " │ ENTER CREATOR ID:   " + RESET);
                    String author = scanner.nextLine();
                    // FIX: Passing a LibbraBook instead of Book
                    library.addBook(new LibbraBook(isbn, title, author));
                    break;
                case 2:
                    library.displayBooks();
                    break;
                case 3:
                    inAdmin = false;
                    printFrame("LOGOUT SECURE", "Admin terminal session ended.", Libb.CYAN);
                    break;
                default:
                    printFrame("ERROR", "Invalid Operation Node.", Libb.RED);
            }
        }
    }

    private static void showUserPanel() {
        boolean inUser = true;
        while (inUser) {
            System.out.println("\n" + GREEN + "╔══════════════════════════════════════════════╗");
            System.out.println("║ " + WHITE + BOLD + "        M A T R I X   U S E R   M E N U        " + GREEN + "║");
            System.out.println("╠══════════════════════════════════════════════╣");
            System.out.println("║ " + CYAN + "  [1] DISPLAY ALL BOOKS               " + GREEN + "║");
            System.out.println("║ " + CYAN + "  [2] BORROW                " + GREEN + "║");
            System.out.println("║ " + CYAN + "  [3] RETURN           " + GREEN + "║");
            System.out.println("║ " + WHITE + "  [4] TERMINATE SESSION             " + GREEN + "║");
            System.out.println("╚══════════════════════════════════════════════╝");
            System.out.print(GREEN + "║ " + YELLOW + "EXECUTE: " + RESET);

            int choice = getIntInput();
            switch (choice) {
                case 1:
                    library.displayBooks();
                    break;
                case 2:
                    System.out.print(GREEN + " │ ENTER ISBN: " + RESET);
                    String borrowIsbn = scanner.nextLine();
                    library.borrowBook(borrowIsbn);
                    break;
                case 3:
                    System.out.print(GREEN + " │ ENTER TARGET RE-ENTRY INDEX (ISBN): " + RESET);
                    String returnIsbn = scanner.nextLine();
                    library.returnBook(returnIsbn);
                    break;
                case 4:
                    inUser = false;
                    printFrame("LOGOUT SECURE", "User mainframe connection closed.", Libb.CYAN);
                    break;
                default:
                    printFrame("ERROR", "Invalid Stream Node.", Libb.RED);
            }
        }
    }

    private static int getIntInput() {
        while (!scanner.hasNextInt()) {
            printFrame("PARSE FAULT", "Integers only. Re-routing input stream...", Libb.RED);
            System.out.print(CYAN + "║ " + YELLOW + "RE-ENTER CHOICE: " + RESET);
            scanner.next();
        }
        int val = scanner.nextInt();
        scanner.nextLine(); 
        return val;
    }

    public static void printFrame(String title, String message, String colorCode) {
        int width = 70;
        String border = colorCode + "▰".repeat(width) + RESET;
        System.out.println(border);
        System.out.printf("%s▰▰ [ %s%s%s ] %s\n", colorCode, WHITE, title, colorCode, ".".repeat(width - title.length() - 9) + RESET);
        System.out.println(WHITE + "  " + message + RESET);
        System.out.println(border);
    }
}
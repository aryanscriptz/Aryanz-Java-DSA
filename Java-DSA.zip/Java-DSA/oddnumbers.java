import java.util.Scanner;

public class oddnumbers {
    public static void main(String[] args) 
    { 
        long n;      
        Scanner sc = new Scanner(System.in);                        
        System.out.println("Enter a number:");
        n = sc.nextLong ();                                       
        for (int i = 1; i <= n; i++) 
        { 
            if (i % 2 != 0) 
            { 
                System.out.println(i);  
            } 
        } 
    }
}

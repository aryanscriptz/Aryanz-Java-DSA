import java.util.List;

public class Stream {

    public static void main(String[] args) {

        //source data

        List <Integer> numbers = List.of(1,2,3,4,5,6);
        System.out.println("Keeping only the even numbers :");
  
        //conveyor belt started
        numbers.stream()

        //intermediate operation
        .filter(n -> n%2 == 0 ) 
        
        //terminal operation

        .forEach (System.out::println);   
    }

    
}

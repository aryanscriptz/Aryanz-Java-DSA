import java.util.*;

interface Calculator {
    double calculate(double a, double b);
}

class File4 {

    public static void main(String[] args) {

         // Calculator addition = (a, b) -> (a + b);
        // System.out.println("The addition of 3 & 5 is : " + addition.calculate(3, 5));

        //   Calculator substraction = (a, b) -> (a - b);
        // System.out.println("The substarcction of 3 & 5 is : " + substraction.calculate(3, 5));

        // Calculator multiplication = (a, b) -> (a * b);
        // System.out.println("The multiplication of 3 & 5 is : " + multiplication.calculate(3, 5));

        // Calculator division = (a, b) -> (a/b);
        // System.out.println("The divison of 3 & 5 is : " + division.calculate(3, 5) ); // Calculator addition = (a, b) -> (a + b);
        // System.out.println("The addition of 3 & 5 is : " + addition.calculate(3, 5));

        //   Calculator substraction = (a, b) -> (a - b);
        // System.out.println("The substarcction of 3 & 5 is : " + substraction.calculate(3, 5));

        // Calculator multiplication = (a, b) -> (a * b);
        // System.out.println("The multiplication of 3 & 5 is : " + multiplication.calculate(3, 5));

        // Calculator division = (a, b) -> (a/b);
        // System.out.println("The divison of 3 & 5 is : " + division.calculate(3, 5) );

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter first number: ");
        double a = sc.nextDouble();

        System.out.print("Enter second number: ");
        double b = sc.nextDouble();

        Calculator addition = (x, y) -> (x + y);
        System.out.println("Addition is : " + addition.calculate(a, b));

        Calculator subtraction = (x, y) -> (x - y);
        System.out.println("Subtraction is : " + subtraction.calculate(a, b));

        Calculator multiplication = (x, y) -> (x * y);
        System.out.println("Multiplication is : " + multiplication.calculate(a, b));

        Calculator division = (x, y) -> (x / y);
        System.out.println("Division is : " + division.calculate(a, b));


         sc.close();
    }
}
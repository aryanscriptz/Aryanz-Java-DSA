import java.util.*;

class MyRunnable implements Runnable {

    @Override
    public void run() {

        for (int i = 1; i <= 5; i++) {

            System.out.println("MyRunnable is running : " + i);

            try {
                Thread.sleep(2000);
            }

            catch (InterruptedException e) {
                System.out.println("Thread interrupted");
            }
        }
    }

    // 2. Implementing from runnable interface

    public static void main(String[] args) {

        System.out.println("Main thread starts....");
        

        Thread t1 = new Thread();
        Thread t2 = new Thread();

        t1.start();
        t2.start();
        try{

            t1.join();
            t2.join();

        } catch(Exception e){
            e.printStackTrace();

        }

        System.out.println("The main thread ends...");

    }
}
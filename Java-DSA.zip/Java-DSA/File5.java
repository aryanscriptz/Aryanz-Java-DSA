import java.util.*;

interface Calculator {
    double calculate(double a, double b);
}

class File5 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Choose operation:");
        System.out.println("1. Add");
        System.out.println("2. Sub");
        System.out.println("3. Multi");
        System.out.println("4. Div");

        System.out.print("Enter your choice: ");
        int choice = sc.nextInt();

        System.out.print("Enter first number: ");
        double a = sc.nextDouble();

        System.out.print("Enter second number: ");
        double b = sc.nextDouble();

        Calculator calculation;

        switch (choice) {

            case 1:
                calculation = (x, y) -> (x + y);
                System.out.println("Addition is : " + calculation.calculate(a, b));
                break;

            case 2:
                calculation = (x, y) -> (x - y);
                System.out.println("Subtraction is : " + calculation.calculate(a, b));
                break;

            case 3:
                calculation = (x, y) -> (x * y);
                System.out.println("Multiplication is : " + calculation.calculate(a, b));
                break;

            case 4:
                try {
                    if (b == 0) {
                        throw new ArithmeticException("INVALID");
                    }

                    else {

                        calculation = (x, y) -> (x / y);
                        System.out.println("Division is : " + calculation.calculate(a, b));

                        break;
                    }

                } catch (ArithmeticException e) {
                    System.out.println("Error :: " + e);
                }

            default:
                System.out.println("TERA FUFAA KREGA ZERO SE DIVIDE");
        }

        sc.close();
    }
}

// create a class called printer. overload a metho called printdocument. one version takes an integer (number of copies) . the other takes a string ( a secret message).
// create a parent class Appliance with a turnOn ()method.create a child class Toaster that overrides turnOn () to say 'Heating up bread'. Test both in your main method.

 class Printer {
    void printdocument(int numbersofcopies) {
        System.out.println("Printing" + numbersofcopies + "copies");

        
    }

//overload method

     void printdocument(String secretmessage) {
        System.out.println("Printing secret message: " + secretmessage);
}
}
    
//task 2 method overriding

class Appliance {
    void turnOn() {
        System.out.println("Turning on appliance");
    }
}

class Toaster extends Appliance {
  
    void turnOn() {
        System.out.println("Heating up bread");
    }
}

//main testing class 

public class Appliancez {
    public static void main(String[] args) {
        
        System.out.println("Testing task");
        Printer printer = new Printer();
        printer.printdocument(5);
        printer.printdocument("This is a secret message.");
        
        Toaster toaster = new Toaster();
        toaster.turnOn();
    }
}
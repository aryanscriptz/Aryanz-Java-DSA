class OddThread extends Thread {

    public void run() {

        for (int i = 1; i <= 9; i += 2) {

            System.out.println("Odd : " + i);

            try {
                Thread.sleep(500);
            }

            catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

class EvenThread extends Thread {

    public void run() {

        for (int i = 2; i <= 10; i += 2) {

            System.out.println("Even : " + i);

            try {
                Thread.sleep(500);
            }

            catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

public class Threaddemo {

    public static void main(String[] args) {

        OddThread t1 = new OddThread();
        EvenThread t2 = new EvenThread();

        t1.start();

        try {
            Thread.sleep(100);
        }

        catch (InterruptedException e) {
            System.out.println(e);
        }

        t2.start();
    }
}
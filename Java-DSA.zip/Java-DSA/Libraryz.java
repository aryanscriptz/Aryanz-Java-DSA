import java.util.ArrayList;
import java.util.Scanner;

class Book {
    int id;
    String title;
    String author;
    boolean issued;
    String rollNumber;

    Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.issued = false;
        this.rollNumber = "";
    }
}

public class Libraryz {

    static ArrayList<Book> books = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    static void addBook() {
        System.out.print("Enter Book ID: ");
        int id = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter Book Title: ");
        String title = sc.nextLine();

        System.out.print("Enter Author Name: ");
        String author = sc.nextLine();

        books.add(new Book(id, title, author));
        System.out.println("Book Added Successfully!");
    }

    static void viewBooks() {
        if (books.isEmpty()) {
            System.out.println("No Books Available.");
            return;
        }

        System.out.println("\n----- BOOK LIST -----");

        for (Book b : books) {
            System.out.println(
                    "ID: " + b.id +
                    " | Title: " + b.title +
                    " | Author: " + b.author +
                    " | Status: " + (b.issued ? "Issued" : "Available") +
                    (b.issued ? " | Issued To: " + b.rollNumber : ""));
        }
    }

    static void searchBook() {
        sc.nextLine();
        System.out.print("Enter Book Title: ");
        String title = sc.nextLine();

        for (Book b : books) {
            if (b.title.equalsIgnoreCase(title)) {
                System.out.println("\nBook Found!");
                System.out.println("ID: " + b.id);
                System.out.println("Title: " + b.title);
                System.out.println("Author: " + b.author);
                System.out.println("Status: " + (b.issued ? "Issued" : "Available"));

                if (b.issued) {
                    System.out.println("Issued To Roll No: " + b.rollNumber);
                }
                return;
            }
        }

        System.out.println("Book Not Found.");
    }

    static void issueBook() {
        System.out.print("Enter Roll Number: ");
        String roll = sc.next();

        System.out.print("Enter Book ID: ");
        int id = sc.nextInt();

        for (Book b : books) {
            if (b.id == id) {

                if (!b.issued) {
                    b.issued = true;
                    b.rollNumber = roll;

                    System.out.println("Book Issued Successfully!");
                    System.out.println("Issued To Roll Number: " + roll);
                } else {
                    System.out.println("Book Already Issued!");
                }
                return;
            }
        }

        System.out.println("Book Not Found.");
    }

    static void returnBook() {
        System.out.print("Enter Roll Number: ");
        String roll = sc.next();

        System.out.print("Enter Book ID: ");
        int id = sc.nextInt();

        for (Book b : books) {
            if (b.id == id) {

                if (!b.issued) {
                    System.out.println("Book Was Not Issued!");
                    return;
                }

                if (!b.rollNumber.equals(roll)) {
                    System.out.println("Incorrect Roll Number!");
                    return;
                }

                b.issued = false;
                b.rollNumber = "";

                System.out.println("Book Returned Successfully!");
                return;
            }
        }

        System.out.println("Book Not Found.");
    }

    public static void main(String[] args) {

        books.add(new Book(101, "Java Programming", "James Gosling"));
        books.add(new Book(102, "Python Basics", "Guido van Rossum"));
        books.add(new Book(103, "Data Structures", "Mark Allen"));
        books.add(new Book(104, "Operating Systems", "Galvin"));
        books.add(new Book(105, "Computer Networks", "Tanenbaum"));

        int choice;

        do {
            System.out.println("\n========== LIBRARY MANAGEMENT SYSTEM ==========");
            System.out.println("1. Add Book");
            System.out.println("2. View Books");
            System.out.println("3. Search Book");
            System.out.println("4. Issue Book");
            System.out.println("5. Return Book");
            System.out.println("6. Exit");
            System.out.print("Enter Choice: ");

            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    addBook();
                    break;

                case 2:
                    viewBooks();
                    break;

                case 3:
                    searchBook();
                    break;

                case 4:
                    issueBook();
                    break;

                case 5:
                    returnBook();
                    break;

                case 6:
                    System.out.println("Thank You!");
                    break;

                default:
                    System.out.println("Invalid Choice!");
            }

        } while (choice != 6);

        sc.close();
    }
}
import java.util.*;

// Synchronized Example

class Counter {

    int count = 0;

    public synchronized void increment() {
        count++;
    }
}

class Race {

    public static void main(String[] args) throws Exception {

        Counter counter = new Counter();

        Runnable task = () -> {

            for (int i = 1; i <= 10000; i++) {
                counter.increment();
            }
        };

        Thread t1 = new Thread(task);
        Thread t2 = new Thread(task);

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println("Final value of counter is : " + counter.count);
    }
}
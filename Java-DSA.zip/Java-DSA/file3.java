import java.util.*;

public class file3 {

    public static void main(String [] args ) {

        Set<String> cars1 = new HashSet<>();
        Set<String> cars2 = new TreeSet<>();
        
        
        cars1.add("Maruti");
        cars1.add("KIA");
        cars1.add("TOYOTA");
        cars1.add("MARUTI");
    
    cars2.add("Maruti");
    cars2.add("Kia");
    cars2.add("Toyota");
    cars2.add("maruti");

    System.out.println(cars1);

    System.out.println(cars2);

    if (cars1.contains ("MARUTI")) {
        
        System.out.println("MARUTI IS PRESENT");
        
    
    }   
    }
    }
    


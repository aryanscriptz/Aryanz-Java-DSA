public class Main {
    public static void main(String[] args) {
        System.out.println("Yeah!,I'mARYAN SHARMA");
        System.out.println("BETN1CS25147");
        System.out.println("B.TECH CSE");
        System.out.println("SEMESTER 2");
        System.out.println("Play Synthesizer as hobby");        
        
        int a = 10;
        int b = 20;
        int c = 30;
        int result = a * b * c;
        System.out.println("Multiplication result: " + result);
    }
}


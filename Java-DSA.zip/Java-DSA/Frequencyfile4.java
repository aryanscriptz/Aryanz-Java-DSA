import java.util.*;

public class Frequencyfile4 {

    public static void main(String[] args) {

        Map<Integer, String> students = new HashMap<>();

        students.put(12, "ARYAN");
        students.put(11, "MIKE");
        students.put(9, "BILLY");
        students.put(11, "ELEVEN");
        students.put(13, "DUSTIN");

        System.out.println(students);

        students.put(12, "Maxx");
        System.out.println(students);

        System.out.println("The value at the 12th key is : " + students.get(12));

        for (Map.Entry<Integer, String> entry : students.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }

        List<Integer> numbers = Arrays.asList(
                1, 1, 2, 2, 1, 1, 3, 5,
                7, 5, 3, 7, 9, 5, 0, 0, 0
        );

        Map<Integer, Integer> freq = new HashMap<>();

        for (int num : numbers) {
            freq.put(num, freq.getOrDefault(num, 0) + 1);
        }

        System.out.println("Frequency of elements:");

        for (Map.Entry<Integer, Integer> entry : freq.entrySet()) {
            System.out.println(entry.getKey() + " -> " + entry.getValue());
        }
    }
}
// create a parent class called shape with a string variable color set to "RED" . Then create a circle class that extends shape. In circle, create its own color variable set to blue.
// write a method in circle that prints both the colors

class shape {
    String color = "RED" ; 
}

class circle extends shape {
    String color = "BLUE";

    void display() {
        System.out.println("The color of circle is:" + color);
        System.out.println("The color of shape is:" + super.color);
    }
}
public class sample {
    public static void main(String[] args) {
        circle c = new circle();
        c.display();
        
    }
}
import java.util

































// import java.util.Scanner;

// public class LibrarySystem {

//     public static void main(String[] args) {

//         Scanner sc = new Scanner(System.in);

//         String[] books = new String[5];

//         int count = 0;
//         int choice;

//         do {

//             System.out.println("\n===== LIBRARY MENU =====");
//             System.out.println("1. Add Book");
//             System.out.println("2. View Books");
//             System.out.println("3. Search Book");
//             System.out.println("4. Remove Book");
//             System.out.println("5. Exit");

//             System.out.print("Enter choice: ");
//             choice = sc.nextInt();
//             sc.nextLine();

//             switch (choice) {

//                 case 1:

//                     if (count < books.length) {

//                         System.out.print("Enter book name: ");
//                         books[count] = sc.nextLine();

//                         count++;

//                         System.out.println("Book Added!");
//                     } else {
//                         System.out.println("Library Full!");
//                     }

//                     break;

//                 case 2:

//                     System.out.println("\nBooks in Library:");

//                     for (int i = 0; i < count; i++) {
//                         System.out.println((i + 1) + ". " + books[i]);
//                     }

//                     break;

//                 case 3:

//                     System.out.print("Enter book name to search: ");
//                     String search = sc.nextLine();

//                     boolean found = false;

//                     for (int i = 0; i < count; i++) {

//                         if (books[i].equalsIgnoreCase(search)) {

//                             System.out.println("Book Found!");
//                             found = true;
//                             break;
//                         }
//                     }

//                     if (!found) {
//                         System.out.println("Book Not Found!");
//                     }

//                     break;

//                 case 4:

//                     System.out.print("Enter book name to remove: ");
//                     String remove = sc.nextLine();

//                     boolean removed = false;

//                     for (int i = 0; i < count; i++) {

//                         if (books[i].equalsIgnoreCase(remove)) {

//                             for (int j = i; j < count - 1; j++) {
//                                 books[j] = books[j + 1];
//                             }

//                             count--;

//                             System.out.println("Book Removed!");
//                             removed = true;
//                             break;
//                         }
//                     }

//                     if (!removed) {
//                         System.out.println("Book Not Found!");
//                     }

//                     break;

//                 case 5:

//                     System.out.println("Exiting...");
//                     break;

//                 default:

//                     System.out.println("Invalid Choice!");
//             }

//         } while (choice != 5);

//         sc.close();
//     }
// }
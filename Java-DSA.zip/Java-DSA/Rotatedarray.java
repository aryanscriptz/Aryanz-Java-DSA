public class Rotatedarray {
    
    
}

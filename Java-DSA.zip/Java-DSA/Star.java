import java.util.*;

public class Star {
    
    public static void main(String[] args) {
         Scanner sc = new Scanner (System.in);
       

        System.out.print("Enter number: ");
         int a = sc.nextInt();
           
       

        System.out.print("Enter next number: ");
         int b = sc.nextInt();
         
        int sum = a + b;

        System.out.print("Sum =" + sum );   


        sc.close();
        
    }
    
}
     

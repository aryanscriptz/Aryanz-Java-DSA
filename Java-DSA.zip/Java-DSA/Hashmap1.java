public class Hashmap1 {
  public static void main(String[] args) {

    int arr[] = {2, 1, 2, 3, 4, 1, 2};
    Hashmap<Integer, Integer> map = new Hashmap<>();
    for(int i = 0; i <arr.length; i++) {
      if 
    }


  }
    
}


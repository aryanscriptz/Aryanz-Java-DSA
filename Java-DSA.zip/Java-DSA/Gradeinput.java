import java.util.Scanner;

public class Gradeinput {
    public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);

            System.out.println("Enter the grade (0-100): ");
            int grade = scanner.nextInt(); 
           
            if (grade < 30) {
                System.out.println("Grade: D");
            } else if (grade >= 30 && grade < 50) {
                System.out.println("Grade: C");
            } else if (grade >= 50 && grade < 70) {
                System.out.println("Grade: B");
            } else if (grade >= 70 && grade <= 90) {
                System.out.println("Grade: A");
            } else {
                System.out.println("Grade: A+");
            }
     
    }
}

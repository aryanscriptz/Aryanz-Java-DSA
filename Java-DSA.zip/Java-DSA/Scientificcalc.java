import java.nio.channels.Pipe.SourceChannel;
import java.util.*;

interface Calculator {
    double calculate(double a, double b);
}

class Scientificcalc {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("\n=========================== Scientific Calculator =========================\n");


        System.out.print("1. Add  ");
        System.out.print("2. Sub  ");
        System.out.print("3. Multi  ");
        System.out.print("4. Div  ");
        System.out.print("5. Power  ");
        System.out.print("6. Square  ");
        System.out.print("7. Square Root  ");
        System.out.print("8. Cube  ");
        System.out.print("9. Cube Root  ");
        System.out.print("10. Sin  ");
        System.out.print("11. Cos  ");
        System.out.print("12. Tan  \n \n");
        System.out.println("Enter your choice: ");
        int choice = sc.nextInt();

        double a, b;

        Calculator calculation;

        switch (choice) {

            case 1:

                System.out.print("Enter first number: ");
                a = sc.nextDouble();

                System.out.print("Enter second number: ");
                b = sc.nextDouble();

                calculation = (x, y) -> (x + y);

                System.out.println("Addition is : " + calculation.calculate(a, b));

                break;

            case 2:

                System.out.print("Enter first number: ");
                a = sc.nextDouble();

                System.out.print("Enter second number: ");
                b = sc.nextDouble();

                calculation = (x, y) -> (x - y);

                System.out.println("Subtraction is : " + calculation.calculate(a, b));

                break;

            case 3:

                System.out.print("Enter first number: ");
                a = sc.nextDouble();

                System.out.print("Enter second number: ");
                b = sc.nextDouble();

                calculation = (x, y) -> (x * y);

                System.out.println("Multiplication is : " + calculation.calculate(a, b));

                break;

            case 4:

                System.out.print("Enter first number: ");
                a = sc.nextDouble();

                System.out.print("Enter second number: ");
                b = sc.nextDouble();

                try {

                    if (b == 0) {
                        throw new ArithmeticException("Cannot divide by zero");
                    }

                    calculation = (x, y) -> (x / y);

                    System.out.println("Division is : " + calculation.calculate(a, b));
                }

                catch (ArithmeticException e) {
                    System.out.println("Error :: " + e.getMessage());
                }

                break;

            case 5:

                System.out.print("Enter base number: ");
                a = sc.nextDouble();

                System.out.print("Enter power: ");
                b = sc.nextDouble();

                System.out.println("Power is : " + Math.pow(a, b));

                break;

            case 6:

                System.out.print("Enter number: ");
                a = sc.nextDouble();

                System.out.println("Square is : " + (a * a));

                break;

            case 7:

                System.out.print("Enter number: ");
                a = sc.nextDouble();

                System.out.println("Square Root is : " + Math.sqrt(a));

                break;

            case 8:

                System.out.print("Enter number: ");
                a = sc.nextDouble();

                System.out.println("Cube is : " + (a * a * a));

                break;

            case 9:

                System.out.print("Enter number: ");
                a = sc.nextDouble();

                System.out.println("Cube Root is : " + Math.cbrt(a));

                break;

            case 10:

                System.out.print("Enter angle: ");
                a = sc.nextDouble();

                System.out.println("Sin value is : " + Math.sin(Math.toRadians(a)));

                break;

            case 11:

                System.out.print("Enter angle: ");
                a = sc.nextDouble();

                System.out.println("Cos value is : " + Math.cos(Math.toRadians(a)));

                break;

            case 12:

                System.out.print("Enter angle: ");
                a = sc.nextDouble();

                System.out.println("Tan value is : " + Math.tan(Math.toRadians(a)));

                break;

            default:

                System.out.println("Invalid Choice");
        }

        sc.close();
    }
}
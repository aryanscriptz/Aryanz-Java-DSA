import java.util.Scanner;

public class Reverseorder1to10 {
    public static void main(String[] args) 
    { 
        int n;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        n = sc.nextInt();       
        System.out.println("Reverse order from " + n + " to 1:");
        for (int i = n; i >= 1; i--) 
        { 
            System.out.println(i);  
        }
    }   
}

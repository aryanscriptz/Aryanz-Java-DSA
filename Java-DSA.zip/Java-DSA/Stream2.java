import java.util.List;
import java.util.stream.Collectors;

public class Stream2 {

    public static void main(String[] args) {

        List<String> rawData = List.of("Apple", "Avacado", "Banana", "Guava" , "PAPAYA" , "Banana" "", "Kiwi");

        List<String> onlyABwords = rawData.stream()
                .filter(w -> w.startsWith("A") || w.startsWith("B"))
                .collect(Collectors.toList());

        System.out.println("Original list :" + rawData);
        System.out.println("New list :" + onlyABwords);
    }
}
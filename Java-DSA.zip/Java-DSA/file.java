import java.util.List;
import java.util.ArrayList;
import java.util.Collections;


public class file {

    public static void main(String[] args) {

        List<String> codingLanguages = new ArrayList<>();

        codingLanguages.add("JAVA");
        codingLanguages.add("C++");
        codingLanguages.add("JAVASCRIPT");
        codingLanguages.add("PYTHON");

        codingLanguages.add(1, "RUST");
        codingLanguages.add(3, "GO");

        System.out.println(codingLanguages);

        System.out.println("THE VALUE AT 2nd INDEX IS:" + codingLanguages.get(2));

        codingLanguages.set(2,"ANACONDA");
        System.out.println(codingLanguages);

        codingLanguages.remove(2);
        System.out.println(codingLanguages);

        Collections.sort(codingLanguages);
        System.out.println(codingLanguages);
       

        System.out.println( "The size of the arraylist is " + codingLanguages.size());

        for(String s: codingLanguages) {
            System.out.println("Language: " + s);

     
        }
        
        }

}
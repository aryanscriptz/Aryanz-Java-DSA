import java.util.*;
public class Useroutput {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println(" Yeah!,I'm ARYAN SHARMA");
        System.out.println("BETN1CS25147");
        System.out.println("B.TECH CSE");
        System.out.println("SEMESTER 2");
        System.out.println("Play Synthesizer as hobby");        
        
        System.out.println("Enter a number: ");
        int a = sc.nextInt();
        System.out.println("Enter another number: ");
        int b = sc.nextInt();
        System.out.println("Enter a third number: ");
        int c = sc.nextInt();
        int result = a * b * c;
        System.out.println("Enter a number: " + a);
        System.out.println("Enter another number: " + b);
        System.out.println("Enter a third number: " + c);
        System.out.println("Multiplication result: " + result);
    }
}

